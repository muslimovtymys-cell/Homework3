namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                label1.Left += 5;
            }
            for (int i = 0; i < 10; i++)
            {
                label1.Top += 5;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                label1.Left -= 5;
            }
            for (int i = 0; i < 10; i++)
            {
                label1.Top -= 5;
            }
        }
    }
}

